package com.allianz.shopping.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.allianz.shopping.model.Order;
import com.allianz.shopping.utility.DBUtility;
import com.allianz.shopping.utility.DateUtility;

public class OrderDAOImpl implements OrderDAO {

	@Override
	public int addOrder(Order order) {
		
		String sql = "INSERT INTO orders(order_date, order_status, user_name, total_price) VALUES(?,?,?,?)";
		Connection con = null;
		int orderId = 0;
		
		try {
			con = DBUtility.getConnection();
			PreparedStatement preparedStatement = con.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
			preparedStatement.setDate(1, DateUtility.ConvertUtilToSql(order.getOrderDate()));
			preparedStatement.setString(2, order.getStatus());
			preparedStatement.setString(3, order.getUsername());
			preparedStatement.setFloat(4, order.getTotalPrice());
			
			int result = preparedStatement.executeUpdate();
			System.out.println("Rows updated is " + result);
			if(result > 0)
			{
				try(ResultSet generatedKeys = preparedStatement.getGeneratedKeys())
				{
					 if (generatedKeys.next()) {
			                orderId = generatedKeys.getInt(1);
			                System.out.println(orderId);
			            }
				}
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return orderId;
	}

}
