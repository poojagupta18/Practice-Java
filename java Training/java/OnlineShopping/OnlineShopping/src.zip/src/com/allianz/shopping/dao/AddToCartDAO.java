package com.allianz.shopping.dao;

import com.allianz.shopping.model.AddToCart;

public interface AddToCartDAO {

	boolean addToCard(AddToCart addtocart);
}
