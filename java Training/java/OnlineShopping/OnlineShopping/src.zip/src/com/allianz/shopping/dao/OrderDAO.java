package com.allianz.shopping.dao;

import com.allianz.shopping.model.Order;

public interface OrderDAO {

	public int addOrder(Order order);
	
}
