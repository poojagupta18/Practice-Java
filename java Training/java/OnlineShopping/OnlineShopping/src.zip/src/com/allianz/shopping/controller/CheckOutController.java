package com.allianz.shopping.controller;

import java.io.IOException;
import java.util.Date;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.allianz.shopping.dao.AddToCardDAOImpl;
import com.allianz.shopping.dao.AddToCartDAO;
import com.allianz.shopping.dao.OrderDAO;
import com.allianz.shopping.dao.OrderDAOImpl;
import com.allianz.shopping.model.AddToCart;
import com.allianz.shopping.model.Order;

/**
 * Servlet implementation class CheckOutController
 */
@WebServlet("/CheckOutController")
public class CheckOutController extends HttpServlet implements Servlet {
	private static final long serialVersionUID = 1L;
    OrderDAO orderDAO = new OrderDAOImpl();
    AddToCartDAO addToCartDAO = new AddToCardDAOImpl();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CheckOutController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username = (String) request.getSession().getAttribute("username");
		String product_id[] = request.getParameterValues("product_id");
		
		System.out.println("Username : " + username);
		System.out.println("inside dopost of product_id " + product_id);
		if(product_id != null && product_id.length > 0)
		{
			Order order = new Order();
			order.setOrderDate(new Date());
			order.setStatus("Ordered");
			order.setUsername(username);
			order.setTotalPrice(0);
			
			int order_id = orderDAO.addOrder(order);
			
			System.out.println("your order id is : " + order_id);
			
			for(int i = 0; i < product_id.length; i++)
			{
				if(product_id[i] != null && !product_id[i].trim().equals(""))
				{
					System.out.println("product_id at index " + i + product_id[i]);
					String quantity = request.getParameter("quantity"+product_id[i]);
					System.out.println("quantity : " + quantity);
					if(quantity != null)
					{
						AddToCart addToCart = new AddToCart();
						addToCart.setOrderId(order_id);
						addToCart.setQuantity(Integer.parseInt(quantity));
						addToCart.setProductId(Integer.parseInt(product_id[i]));
						
						addToCartDAO.addToCard(addToCart);
					}
				}
			}
			
		}
	}

}
