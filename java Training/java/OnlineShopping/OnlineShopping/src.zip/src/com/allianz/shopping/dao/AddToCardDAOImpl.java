package com.allianz.shopping.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.allianz.shopping.model.AddToCart;
import com.allianz.shopping.utility.DBUtility;
import com.allianz.shopping.utility.DateUtility;

public class AddToCardDAOImpl implements AddToCartDAO {

	@Override
	public boolean addToCard(AddToCart addtocart) {
		String sql = "INSERT INTO addtocart(order_id, product_id, quantity) VALUES(?,?,?)";
		Connection con = null;
		int orderId = 0;
		
		try {
			con = DBUtility.getConnection();
			PreparedStatement preparedStatement = con.prepareStatement(sql);
			preparedStatement.setInt(1, addtocart.getOrderId());
			preparedStatement.setInt(2, addtocart.getProductId());
			preparedStatement.setInt(3, addtocart.getQuantity());
			
			int result = preparedStatement.executeUpdate();
			System.out.println("Rows updated is " + result);
			if(result > 0)
			{
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return false;
	}

}
