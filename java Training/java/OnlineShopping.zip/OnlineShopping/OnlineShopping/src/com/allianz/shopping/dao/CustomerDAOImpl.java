package com.allianz.shopping.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.allianz.shopping.model.Customer;
import com.allianz.shopping.utility.DBUtility;

public class CustomerDAOImpl implements CustomerDAO {

	@Override
	public boolean register(Customer customer) {
		System.out.println("inside register");
		Connection conn = null;
		String sql = "insert into customer(name, username, password ,phonenumber) values(?,?,?,?)";
		try {
			
			
			conn = DBUtility.getConnection();
			
			PreparedStatement preparedStatement = conn.prepareStatement(sql);
			//preparedStatement.setInt(1, customer.getCustomerId());
			preparedStatement.setString(1, customer.getName());	
			preparedStatement.setString(2, customer.getUsername());
			preparedStatement.setString(3, customer.getPassword());
			preparedStatement.setString(4, customer.getPhonenumber());
			
			int result = preparedStatement.executeUpdate();
			
			if(result > 0)
			{
				System.out.println("user added");
				return true;
			}
			
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		System.out.println("user not added");
		return false;
	}

	@Override
	public int login(String username, String password) {
		String sql = "SELECT * from customer where username=? and password=?";
		Connection con = DBUtility.getConnection();
		int id = 0;
		
		try {
			PreparedStatement preparedStatement = con.prepareStatement(sql);
			preparedStatement.setString(1, username);
			preparedStatement.setString(2, password);
			ResultSet rs = preparedStatement.executeQuery();
			
			if(rs.next())
			{
				id = rs.getInt("customer_id");
			}
			
		} catch (SQLException e) {

			e.printStackTrace();
		}
		System.out.println("Invalid user");	
		return id;
	}

}
